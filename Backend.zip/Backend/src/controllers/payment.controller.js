const mongoose = require('mongoose');
const crypto = require('crypto');

const Order = require('../models/order.model');
const Payment = require('../models/payment.model');
const Reservation = require('../models/reservation.model');
const Inventory = require('../models/inventory.model');

const {
    createRazorpayOrder
} = require('../services/payment.service');


// ======================================================
// CREATE PAYMENT
// ======================================================

async function createPayment(req, res) {
    try {
        const { orderId } = req.params;

        const order = await Order.findOne({
            _id: orderId,
            user: req.user.id
        });

        if (!order) {
            return res.status(404).json({
                message: 'Order not found'
            });
        }

        if (order.paymentStatus === 'paid') {
            return res.status(400).json({
                message: 'Order is already paid'
            });
        }

        // Ensure every order item still has an active reservation.
        const activeReservations = await Reservation.find({
            order: order._id,
            status: 'reserved',
            expiresAt: { $gt: new Date() }
        });

        if (
            activeReservations.length === 0 ||
            activeReservations.length !== order.items.length
        ) {
            return res.status(409).json({
                message: 'Inventory reservation expired. Please checkout again.'
            });
        }

        // Reuse the latest attempt if it is still active.
        const latestPayment = await Payment.findOne({
            order: order._id
        }).sort({ createdAt: -1 });

        if (
            latestPayment &&
            ['created', 'pending'].includes(latestPayment.status) &&
            latestPayment.providerOrderId
        ) {
            return res.status(200).json({
                message: 'Payment attempt already exists',
                payment: latestPayment,
                razorpayOrderId: latestPayment.providerOrderId,
                keyId: process.env.RAZORPAY_KEY_ID
            });
        }

        // Create a fresh Razorpay order for this attempt.
        const razorpayOrder = await razorpay.orders.create({
            amount: Math.round(order.totalAmount * 100),
            currency: 'INR',
            receipt: `${order._id}-${Date.now()}`
        });

        // Keep previous failed attempts for audit history.
        const payment = await Payment.create({
            order: order._id,
            user: req.user.id,
            amount: order.totalAmount,
            currency: 'INR',
            provider: 'razorpay',
            providerOrderId: razorpayOrder.id,
            status: 'created'
        });

        return res.status(201).json({
            message: 'Payment attempt created',
            payment,
            razorpayOrderId: razorpayOrder.id,
            keyId: process.env.RAZORPAY_KEY_ID
        });
    } catch (error) {
        console.error('Create payment error:', error.message);

        return res.status(500).json({
            message: 'Failed to create payment'
        });
    }
}


// ======================================================
// RAZORPAY WEBHOOK
// ======================================================


async function handleWebhook(req, res) {
    const signature = req.headers['x-razorpay-signature'];

    if (!signature) {
        return res.status(400).json({
            message: 'Missing Razorpay signature'
        });
    }

    if (!Buffer.isBuffer(req.body)) {
        return res.status(400).json({
            message: 'Webhook requires a raw request body'
        });
    }

    const webhookSecret = process.env.RAZORPAY_WEBHOOK_SECRET;

    if (!webhookSecret) {
        console.error('Razorpay webhook secret is not configured');

        return res.status(500).json({
            message: 'Webhook configuration error'
        });
    }

    let session;

    try {
        // 1. Verify Razorpay signature
        const expectedSignature = crypto
            .createHmac('sha256', webhookSecret)
            .update(req.body)
            .digest('hex');

        const expectedBuffer = Buffer.from(expectedSignature);
        const receivedBuffer = Buffer.from(signature);

        if (
            expectedBuffer.length !== receivedBuffer.length ||
            !crypto.timingSafeEqual(expectedBuffer, receivedBuffer)
        ) {
            return res.status(400).json({
                message: 'Invalid webhook signature'
            });
        }

        // 2. Parse and filter the event
        const event = JSON.parse(req.body.toString());

        if (
            event.event !== 'payment.captured' &&
            event.event !== 'payment.failed'
        ) {
            return res.status(200).json({
                message: 'Event ignored'
            });
        }

        const razorpayPayment = event.payload?.payment?.entity;

        if (
            !razorpayPayment?.id ||
            !razorpayPayment?.order_id
        ) {
            return res.status(400).json({
                message: 'Invalid payment payload'
            });
        }

        session = await mongoose.startSession();

        let outcome = 'Webhook processed successfully';

        await session.withTransaction(async () => {
            // 3. Find the payment attempt
            const payment = await Payment.findOne({
                providerOrderId: razorpayPayment.order_id
            }).session(session);

            if (!payment) {
                throw new Error('Payment record not found');
            }

            // 4. Verify amount and currency
            const expectedAmount = Math.round(payment.amount * 100);

            if (
                Number(razorpayPayment.amount) !== expectedAmount ||
                razorpayPayment.currency !== payment.currency
            ) {
                throw new Error('Payment amount or currency mismatch');
            }

            // 5. Handle duplicate or out-of-order events
            if (payment.status === 'paid') {
                outcome = 'Payment already processed';
                return;
            }

            if (
                event.event === 'payment.failed' &&
                payment.status === 'failed'
            ) {
                outcome = 'Payment failure already processed';
                return;
            }

            const order = await Order.findById(payment.order)
                .session(session);

            if (!order) {
                throw new Error('Order not found');
            }

            // 6. Payment failed: preserve reservations for retry
            if (event.event === 'payment.failed') {
                payment.providerPaymentId = razorpayPayment.id;
                payment.status = 'failed';
                payment.failureReason =
                    razorpayPayment.error_description ||
                    'Payment failed';

                await payment.save({ session });

                // Never overwrite a successful order status.
                if (order.paymentStatus !== 'paid') {
                    order.paymentStatus = 'unpaid';
                    await order.save({ session });
                }

                outcome = 'Payment failure recorded; reservation retained';
                return;
            }

            // 7. Payment captured
            payment.providerPaymentId = razorpayPayment.id;
            payment.status = 'paid';
            payment.paidAt = new Date();
            payment.failureReason = null;

            await payment.save({ session });

            // A different payment attempt may already have paid this order.
            // Do not deduct inventory twice.
            if (order.paymentStatus === 'paid') {
                outcome = 'Duplicate charge detected; refund review required';
                return;
            }

            // 8. Confirm that every order item still has a valid reservation
            const reservations = await Reservation.find({
                order: order._id,
                status: 'reserved',
                expiresAt: { $gt: new Date() }
            }).session(session);

            if (
                reservations.length === 0 ||
                reservations.length !== order.items.length
            ) {
                // The provider captured the money, but inventory is no
                // longer secured. Preserve the payment record for review.
                outcome =
                    'Payment captured but inventory unavailable; refund review required';

                return;
            }

            // 9. Confirm reserved inventory atomically
            for (const reservation of reservations) {
                const updatedInventory = await Inventory.findOneAndUpdate(
                    {
                        product: reservation.product,
                        variants: {
                            $elemMatch: {
                                name: reservation.variant,
                                reservedStock: {
                                    $gte: reservation.quantity
                                }
                            }
                        }
                    },
                    {
                        $inc: {
                            'variants.$.totalStock': -reservation.quantity,
                            'variants.$.reservedStock': -reservation.quantity
                        }
                    },
                    {
                        new: true,
                        session
                    }
                );

                if (!updatedInventory) {
                    throw new Error(
                        `Unable to confirm stock for ${reservation.variant}`
                    );
                }

                reservation.status = 'confirmed';
                await reservation.save({ session });
            }

            // Mark the order paid only after all inventory is confirmed.
            order.paymentStatus = 'paid';
            await order.save({ session });
        });

        return res.status(200).json({
            message: outcome
        });
    } catch (error) {
        console.error('Webhook error:', error.message);

        return res.status(500).json({
            message: 'Webhook processing failed'
        });
    } finally {
        if (session) {
            await session.endSession();
        }
    }
}



module.exports = {
    createPayment,
    handleWebhook
};