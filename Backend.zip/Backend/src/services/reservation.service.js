
const mongoose = require('mongoose');

const Reservation = require('../models/reservation.model');
const Inventory = require('../models/inventory.model');
const Order = require('../models/order.model');

let expiryJobRunning = false;

async function expireReservations() {
    // Prevent overlapping runs within this backend process.
    if (expiryJobRunning) {
        return;
    }

    expiryJobRunning = true;

    try {
        const now = new Date();

        const expiredCandidates = await Reservation.find({
            status: 'reserved',
            expiresAt: { $lte: now }
        }).select('_id');

        for (const candidate of expiredCandidates) {
            const session = await mongoose.startSession();

            try {
                await session.withTransaction(async () => {
                    // Claim only a reservation that is still eligible to expire.
                    const reservation = await Reservation.findOneAndUpdate(
                        {
                            _id: candidate._id,
                            status: 'reserved',
                            expiresAt: { $lte: new Date() }
                        },
                        {
                            $set: { status: 'expired' }
                        },
                        {
                            new: true,
                            session
                        }
                    );

                    if (!reservation) {
                        return;
                    }

                    // Do not release stock if payment has already succeeded.
                    const order = await Order.findById(
                        reservation.order
                    ).session(session);

                    if (!order) {
                        throw new Error('Order not found');
                    }

                    if (order.paymentStatus === 'paid') {
                        throw new Error(
                            'Cannot expire a reservation for a paid order'
                        );
                    }

                    const updatedInventory =
                        await Inventory.findOneAndUpdate(
                            {
                                product: reservation.product,
                                variants: {
                                    $elemMatch: {
                                        name: reservation.variant,
                                        reservedStock: {
                                            $gte: reservation.quantity
                                        }
                                    }
                                }
                            },
                            {
                                $inc: {
                                    'variants.$.availableStock':
                                        reservation.quantity,
                                    'variants.$.reservedStock':
                                        -reservation.quantity
                                }
                            },
                            {
                                new: true,
                                session
                            }
                        );

                    if (!updatedInventory) {
                        throw new Error(
                            `Unable to release inventory for reservation ${reservation._id}`
                        );
                    }

                    // Change order status only if no active reservations remain.
                    const activeReservations = await Reservation.exists({
                        order: reservation.order,
                        status: 'reserved'
                    }).session(session);

                    if (!activeReservations && order.paymentStatus !== 'paid') {
                        order.paymentStatus = 'unpaid';
                        await order.save({ session });
                    }
                });
            } catch (error) {
                console.error(
                    `Failed to expire reservation ${candidate._id}:`,
                    error.message
                );
            } finally {
                await session.endSession();
            }
        }
    } catch (error) {
        console.error('Reservation expiry job failed:', error.message);
    } finally {
        expiryJobRunning = false;
    }
}

module.exports = {
    expireReservations
};
